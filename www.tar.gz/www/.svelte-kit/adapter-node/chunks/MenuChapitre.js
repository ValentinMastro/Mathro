import { c as create_ssr_component, d as add_attribute, e as escape, f as each } from "./ssr.js";
const MenuChapitre_svelte_svelte_type_style_lang = "";
const css = {
  code: "img.svelte-x8mo9c{aspect-ratio:33/53}a.svelte-x8mo9c{text-decoration:none}div#carte.svelte-x8mo9c{background-color:white;width:28vw;height:265px;color:rgb(55, 55, 55);display:flex;flex-direction:row}div#description.svelte-x8mo9c{width:calc(28vw - 165px);display:flex;flex-direction:column}div#numero.svelte-x8mo9c,div#titre.svelte-x8mo9c{text-align:center;vertical-align:middle}div#numero.svelte-x8mo9c{font-size:3ex;font-weight:bold}div#sommaire.svelte-x8mo9c{height:100%;padding:8px}div#categories.svelte-x8mo9c{height:35px;display:flex;flex-direction:row;align-items:center;column-gap:4px;padding-left:4px;background-color:rgb(245, 245, 245)}div.categorie.svelte-x8mo9c{border-radius:10px;color:white;font-size:10px;text-decoration:none;display:inline-block;font-weight:700;height:18px;line-height:18px;padding:0 9px;text-transform:lowercase}@media(max-width: 1630px){div#carte.svelte-x8mo9c{width:45vw}div#description.svelte-x8mo9c{width:calc(45vw - 165px)}}@media(max-width: 1050px){div#carte.svelte-x8mo9c{width:90vw}div#description.svelte-x8mo9c{width:calc(90vw - 165px)}}",
  map: null
};
const MenuChapitre = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { index } = $$props;
  let { url } = $$props;
  let { titre } = $$props;
  let { cats } = $$props;
  let { img = "https://placehold.co/165x265" } = $$props;
  let categories = [
    {
      nom: "Nombres et calculs",
      visible: false,
      couleur: "rgb(52, 128, 234)"
    },
    {
      nom: "Organisation et gestion de données",
      visible: false,
      couleur: "red"
    },
    {
      nom: "Grandeurs et mesures",
      visible: false,
      couleur: "orange"
    },
    {
      nom: "Espace et géométrie",
      visible: false,
      couleur: "green"
    },
    {
      nom: "Algorithmique et programmation",
      visible: false,
      couleur: "purple"
    }
  ];
  cats.forEach((element) => {
    for (var i = 0; i < categories.length; i++) {
      if (categories[i].nom == element) {
        categories[i].visible = true;
      }
    }
  });
  if ($$props.index === void 0 && $$bindings.index && index !== void 0)
    $$bindings.index(index);
  if ($$props.url === void 0 && $$bindings.url && url !== void 0)
    $$bindings.url(url);
  if ($$props.titre === void 0 && $$bindings.titre && titre !== void 0)
    $$bindings.titre(titre);
  if ($$props.cats === void 0 && $$bindings.cats && cats !== void 0)
    $$bindings.cats(cats);
  if ($$props.img === void 0 && $$bindings.img && img !== void 0)
    $$bindings.img(img);
  $$result.css.add(css);
  return `<a${add_attribute("href", url, 0)} data-sveltekit-reload data-sveltekit-preload-data="off" class="svelte-x8mo9c"><div id="carte" class="svelte-x8mo9c"><img${add_attribute("src", img, 0)} alt="${"mage d'illustration du chapitre " + escape(index, true)}" class="svelte-x8mo9c"> <div id="description" class="svelte-x8mo9c"><div id="chapitre"><div id="numero" class="svelte-x8mo9c"><span id="index">Chapitre ${escape(index.toLocaleString("fr", { minimumIntegerDigits: 2 }))}</span></div> <div id="titre" class="svelte-x8mo9c"><span>${escape(titre)}</span></div></div> <div id="sommaire" class="svelte-x8mo9c"><i>${slots.default ? slots.default({}) : ``}</i></div> <div id="categories" class="svelte-x8mo9c">${each(categories, (categorie) => {
    return `${categorie.visible ? `<div class="categorie svelte-x8mo9c" style="${"background-color: " + escape(categorie.couleur, true) + ";"}">${escape(categorie.nom)}</div>` : ``}`;
  })}</div></div></div> </a>`;
});
export {
  MenuChapitre as M
};
