import { c as create_ssr_component, d as add_attribute, e as escape, f as each, v as validate_component } from "./ssr.js";
import "katex";
const Katex = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { displayMode = false } = $$props;
  let output;
  let latex;
  if ($$props.displayMode === void 0 && $$bindings.displayMode && displayMode !== void 0)
    $$bindings.displayMode(displayMode);
  return ` <span style="display: none;"${add_attribute("this", latex, 0)}>${slots.default ? slots.default({}) : ``}</span>  <span${add_attribute("this", output, 0)}></span>`;
});
const Chapitre_svelte_svelte_type_style_lang = "";
const css$5 = {
  code: ".svelte-901sx4{font-family:Marianne}h2.titre.svelte-901sx4{color:rgb(225, 0, 0);font-size:xx-large;font-weight:bold}",
  map: null
};
const Chapitre = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { numero } = $$props;
  let { titre } = $$props;
  if ($$props.numero === void 0 && $$bindings.numero && numero !== void 0)
    $$bindings.numero(numero);
  if ($$props.titre === void 0 && $$bindings.titre && titre !== void 0)
    $$bindings.titre(titre);
  $$result.css.add(css$5);
  return `<h2 class="titre svelte-901sx4">Chapitre ${escape(numero)}<br class="svelte-901sx4">${escape(titre)}</h2> ${slots.default ? slots.default({}) : ``}`;
});
const Partie_svelte_svelte_type_style_lang = "";
const css$4 = {
  code: "h3.partie.svelte-7k7bss{color:rgb(225, 0, 0);font-size:x-large;font-weight:bold}",
  map: null
};
function romain(i) {
  switch (i) {
    case 1:
    case 2:
    case 3:
      return "I".repeat(i);
    case 4:
      return "IV";
    case 5:
      return "V";
    case 6:
    case 7:
    case 8:
      return "V" + "I".repeat(i - 5);
    default:
      return "ERREUR";
  }
}
const Partie = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { numero } = $$props;
  let { titre } = $$props;
  if ($$props.numero === void 0 && $$bindings.numero && numero !== void 0)
    $$bindings.numero(numero);
  if ($$props.titre === void 0 && $$bindings.titre && titre !== void 0)
    $$bindings.titre(titre);
  $$result.css.add(css$4);
  return `<h3 class="partie svelte-7k7bss">${escape(romain(numero))} - ${escape(titre)}</h3> ${slots.default ? slots.default({}) : ``}`;
});
const SousPartie_svelte_svelte_type_style_lang = "";
const css$3 = {
  code: "h4.souspartie.svelte-ln4ziy{font-size:large;color:green}",
  map: null
};
const SousPartie = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { numero } = $$props;
  let { titre } = $$props;
  if ($$props.numero === void 0 && $$bindings.numero && numero !== void 0)
    $$bindings.numero(numero);
  if ($$props.titre === void 0 && $$bindings.titre && titre !== void 0)
    $$bindings.titre(titre);
  $$result.css.add(css$3);
  return `<h4 class="souspartie svelte-ln4ziy">${escape(String.fromCharCode(numero + 96))}) ${escape(titre)}</h4> ${slots.default ? slots.default({}) : ``}`;
});
const Definition_svelte_svelte_type_style_lang = "";
const css$2 = {
  code: "div.svelte-ohbdif{color:green}",
  map: null
};
const Definition = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css$2);
  return `<div class="svelte-ohbdif"><u data-svelte-h="svelte-1o2gnad">Définition :</u><br> ${slots.default ? slots.default({}) : ``} </div>`;
});
const Exemple_svelte_svelte_type_style_lang = "";
const css$1 = {
  code: "div.svelte-ge0z59{color:blue}table.svelte-ge0z59{columns:50px}",
  map: null
};
const Exemple = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { exercice } = $$props;
  let { nombre } = $$props;
  let exemples = Array(nombre);
  function boucle() {
    for (var i = 0; i < exemples.length; i++) {
      exemples[i] = exercice.exemple_unitaire();
    }
  }
  boucle();
  if ($$props.exercice === void 0 && $$bindings.exercice && exercice !== void 0)
    $$bindings.exercice(exercice);
  if ($$props.nombre === void 0 && $$bindings.nombre && nombre !== void 0)
    $$bindings.nombre(nombre);
  $$result.css.add(css$1);
  return `<div class="svelte-ge0z59"><u>${escape(nombre > 1 ? "Exemples" : "Exemple")} :</u><br> <table class="svelte-ge0z59">${slots.default ? slots.default({}) : ``} ${each(exemples, (exemple) => {
    return `<tr>${each(exemple, (d) => {
      return `${d["type"] == "formule" ? `<td>${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
        default: () => {
          return `${escape(d["valeur"])}`;
        }
      })}</td>` : `${d["type"] == "coche" ? `${d["valeur"] ? `<td style="color: green;">${escape("☑")}</td>` : `<td style="color: red;">${escape("☒")}</td>`}` : `${d["type"] == "nombre" ? `<td>${escape(d["valeur"].toLocaleString())}</td>` : `${d["type"] == "texte" ? `<td>${escape(d["valeur"])}</td>` : `${escape(console.log(d))} <td>${escape(d)}</td>`}`}`}`}`;
    })} </tr>`;
  })}</table> </div>`;
});
const Remarque_svelte_svelte_type_style_lang = "";
const Schema = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let canvasElement;
  let { fonctionAnimation } = $$props;
  if ($$props.fonctionAnimation === void 0 && $$bindings.fonctionAnimation && fonctionAnimation !== void 0)
    $$bindings.fonctionAnimation(fonctionAnimation);
  return `<canvas${add_attribute("this", canvasElement, 0)} data-svelte-h="svelte-1uxaxqi">Ce navigateur ne prend pas en charge les animations html5.
</canvas>`;
});
const Propriete_svelte_svelte_type_style_lang = "";
const css = {
  code: "div.svelte-1i1hglf{color:red}",
  map: null
};
const Propriete = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<div class="svelte-1i1hglf"><u data-svelte-h="svelte-14hieo8">Propriété :</u><br> ${slots.default ? slots.default({}) : ``} </div>`;
});
export {
  Chapitre as C,
  Definition as D,
  Exemple as E,
  Katex as K,
  Partie as P,
  SousPartie as S,
  Schema as a,
  Propriete as b
};
