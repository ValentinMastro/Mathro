class Nombre {
  min;
  max;
  precision;
  fn;
  constructor(min, max, precision = 0, fn = (nombre) => {
    return nombre;
  }) {
    this.min = min;
    this.max = max;
    this.precision = Math.pow(10, precision);
    this.fn = fn;
  }
  // Renvoie une valeur aléatoire entre min et max
  valeur() {
    var valeur = Math.floor((Math.random() * (this.max - this.min + 1) + this.min) * this.precision) / this.precision;
    return this.fn(valeur);
  }
  // Renvoie une valeur satisfaisant une condition
  jusquà(condition) {
    let v;
    do {
      v = this.valeur();
    } while (!condition(v));
    return v;
  }
  // Renvoie plusieurs valeurs différentes satisfaisant une condition
  multiple_jusquà(nombre_de_valeurs, condition) {
    let ensemble = /* @__PURE__ */ new Set();
    let v;
    do {
      v = this.valeur();
      if (condition(v) && !ensemble.has(v)) {
        ensemble.add(v);
      }
    } while (ensemble.size < nombre_de_valeurs);
    return Array.from(ensemble);
  }
}
class Parmi {
  valeurs;
  constructor(valeurs) {
    this.valeurs = valeurs;
  }
  valeur() {
    var n = this.valeurs.length;
    var index = Math.floor(Math.random() * n);
    if (this.valeurs[index] instanceof Array) {
      var index_bis = Math.floor(Math.random() * this.valeurs[index].length);
      return this.valeurs[index][index_bis];
    } else if (this.valeurs[index] instanceof Nombre) {
      return this.valeurs[index].valeur();
    } else {
      return this.valeurs[index];
    }
  }
  // Renvoie une valeur satisfaisant une condition
  jusquà(condition) {
    let v;
    do {
      v = this.valeur();
    } while (!condition(v));
    return v;
  }
  // Renvoie plusieurs valeurs différentes satisfaisant une condition
  multiple_jusquà(nombre_de_valeurs, condition) {
    let ensemble = /* @__PURE__ */ new Set();
    let v;
    do {
      v = this.valeur();
      if (condition(v) && !ensemble.has(v)) {
        ensemble.add(v);
      }
    } while (ensemble.size < nombre_de_valeurs);
    return Array.from(ensemble);
  }
  multiple(nombre_de_valeurs) {
    return this.multiple_jusquà(nombre_de_valeurs, (valeur) => {
      return true;
    });
  }
}
class Formule {
  chaine;
  constructor(chaine) {
    this.chaine = chaine;
  }
}
class Exercice {
  enonce = "";
  bonne_reponse = void 0;
  mauvaises_reponses = [];
  nombre_reponses = 5;
  constructor() {
  }
  est_reponse_valide(valeur) {
    return true;
  }
  est_reponse_invalide(valeur) {
    return false;
  }
  qcm() {
  }
  vraifaux() {
  }
  afficher_qcm() {
    this.qcm();
    return {
      "type": "QCM",
      "enonce": this.enonce,
      "reponse": {
        "bonne": this.bonne_reponse,
        "mauvaises": this.mauvaises_reponses
      }
    };
  }
  afficher_vraifaux() {
    this.vraifaux();
    return {
      "type": "VraiFaux",
      "enonce": this.enonce,
      "reponse": this.bonne_reponse
    };
  }
  exemple_unitaire() {
    throw new Error("Not implemented");
  }
}
class Lettre extends Parmi {
  constructor() {
    super([
      "A",
      "B",
      "C",
      "D",
      "E",
      "F",
      "G",
      "H",
      "I",
      "J",
      "K",
      "L",
      "M",
      "N",
      "O",
      "P",
      "Q",
      "R",
      "S",
      "T",
      "U",
      "V",
      "W",
      "X",
      "Y",
      "Z"
    ]);
  }
}
export {
  Exercice as E,
  Formule as F,
  Lettre as L,
  Nombre as N,
  Parmi as P
};
