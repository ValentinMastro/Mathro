import { j as json } from "../../../chunks/index.js";
import { $ } from "execa";
const POST = async ({ request }) => {
  const { type, niveau, id_exercice } = await request.json();
  const { stdout } = await $`./exercices ${type} ${niveau} ${id_exercice}`;
  return json(JSON.parse(stdout));
};
export {
  POST
};
