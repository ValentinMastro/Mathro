import { c as create_ssr_component, v as validate_component } from "../../../../chunks/ssr.js";
import { M as MenuChapitre } from "../../../../chunks/MenuChapitre.js";
const _page__svelte_svelte_type_style_lang = "";
const css = {
  code: 'div#menu.svelte-e6s43z.svelte-e6s43z{display:flex;flex-direction:row;flex-wrap:wrap;justify-content:space-evenly;row-gap:50px}ol.svelte-e6s43z.svelte-e6s43z{padding:10px}ol.svelte-e6s43z li.svelte-e6s43z{list-style-type:none;counter-increment:step-counter}ol.svelte-e6s43z li.svelte-e6s43z:before{content:counter(step-counter, upper-roman) " - "}',
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `${$$result.head += `<!-- HEAD_svelte-3xflc2_START -->${$$result.title = `<title>Cours : 6ème</title>`, ""}<meta name="description" content="Cours de quatrième"><!-- HEAD_svelte-3xflc2_END -->`, ""} <div id="menu" class="svelte-e6s43z">${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 0,
      titre: "Notation positionnelle des nombres",
      url: "/cours/6eme/chapitre00",
      cats: ["Nombres et calculs"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-1cetdev"><li class="svelte-e6s43z">Chiffres et nombres</li> <li class="svelte-e6s43z">Comparaison</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 1,
      titre: "Notation géométrique",
      url: "/cours/6eme/chapitre01",
      cats: ["Espace et géométrie"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-qy1elg"><li class="svelte-e6s43z">Droite, demi-droite, segment</li> <li class="svelte-e6s43z">Polygones</li> <li class="svelte-e6s43z">Points et appartenance</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 2,
      titre: "Repérage et comparaison",
      url: "/cours/6eme/chapitre02",
      cats: ["Espace et géométrie"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-e7k7id"><li class="svelte-e6s43z">Repérage sur une droite</li> <li class="svelte-e6s43z">Comparaison et encadrement</li> <li class="svelte-e6s43z">Repérage dans un plan</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 3,
      titre: "Addition et soustraction",
      url: "/cours/6eme/chapitre03",
      cats: ["Espace et géométrie", "Grandeurs et mesures"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-1ejvqk2"><li class="svelte-e6s43z">Addition</li> <li class="svelte-e6s43z">Soustraction</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 4,
      titre: "Angles",
      url: "/cours/6eme/chapitre04",
      cats: ["Espace et géométrie", "Grandeurs et mesures"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-bgwiee"><li class="svelte-e6s43z">Concept</li> <li class="svelte-e6s43z">Les types d&#39;angles</li> <li class="svelte-e6s43z">Les angles dans un triangle</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 5,
      titre: "Fractions",
      url: "/cours/6eme/chapitre05",
      cats: ["Nombres et calculs"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-198pm19"><li class="svelte-e6s43z">Représentation de fractions</li> <li class="svelte-e6s43z">Addition de fractions</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 6,
      titre: "Cercle, centre, milieu, médiatrice",
      url: "/cours/6eme/chapitre06",
      cats: ["Espace et géométrie"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-dnk4nz"><li class="svelte-e6s43z">Cercle</li> <li class="svelte-e6s43z">Médiatrice</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 7,
      titre: "Multiplication",
      url: "/cours/6eme/chapitre07",
      cats: ["Nombres et calculs"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-1ewpuv0"><li class="svelte-e6s43z">Multiplier et diviser par 1,10,100,etc.</li> <li class="svelte-e6s43z">Multiplication décimale</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 8,
      titre: "Droites parallèles et perpendiculaires",
      url: "/cours/6eme/chapitre08",
      cats: ["Espace et géométrie"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-1bc9gh7"><li class="svelte-e6s43z">Définitions</li> <li class="svelte-e6s43z">Propriétés</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 9,
      titre: "Divisions",
      url: "/cours/6eme/chapitre09",
      cats: ["Nombres et calculs"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-1j8oskt"><li class="svelte-e6s43z">Division euclidienne</li> <li class="svelte-e6s43z">Divisibilité</li> <li class="svelte-e6s43z">Division décimale</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 10,
      titre: "Triangles",
      url: "/cours/6eme/chapitre10",
      cats: ["Espace et géométrie"]
    },
    {},
    {}
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 11,
      titre: "Horaires et durées",
      url: "/cours/6eme/chapitre11",
      cats: ["Grandeurs et mesures"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-1nc0oq7"><li class="svelte-e6s43z">Horaires</li> <li class="svelte-e6s43z">Dates</li> <li class="svelte-e6s43z">Conversion</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 12,
      titre: "Décompositions en facteurs premiers",
      url: "/cours/6eme/chapitre12",
      cats: ["Nombres et calculs"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-1hv17l2"><li class="svelte-e6s43z">Les nombres premiers</li> <li class="svelte-e6s43z">Théorème fondamental de l&#39;arithmétique</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 13,
      titre: "Proportionnalité",
      url: "/cours/6eme/chapitre13",
      cats: ["Nombres et calculs", "Organisation et gestion de données"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-6ulef7"><li class="svelte-e6s43z">Grandeurs proportionnelles</li> <li class="svelte-e6s43z">Quatrième proportionnelle</li> <li class="svelte-e6s43z">Pourcentages</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 14,
      titre: "Enchaînement d'opérations",
      url: "/cours/6eme/chapitre14",
      cats: ["Nombres et calculs"]
    },
    {},
    {}
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 15,
      titre: "Quadrilatères",
      url: "cours/6eme/chapitre15",
      cats: ["Espace et géométrie"]
    },
    {},
    {}
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 16,
      titre: "Périmètres",
      url: "cours/6eme/chapitre16",
      cats: ["Espace et géométrie", "Grandeurs et mesures"]
    },
    {},
    {}
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 17,
      titre: "Tableaux et diagrammes",
      url: "cours/6eme/chapitre17",
      cats: ["Organisation et gestion de données"]
    },
    {},
    {}
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 18,
      titre: "Aires",
      url: "cours/6eme/chapitre18",
      cats: ["Espace et géométrie", "Grandeurs et mesures"]
    },
    {},
    {}
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 19,
      titre: "Échelle et vitesse",
      url: "cours/6eme/chapitre19",
      cats: ["Grandeurs et mesures", "Nombres et calculs"]
    },
    {},
    {}
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 20,
      titre: "Solides et volumes",
      url: "cours/6eme/chapitre20",
      cats: ["Grandeurs et mesures", "Espace et géométrie"]
    },
    {},
    {}
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 21,
      titre: "Programmation",
      url: "cours/6eme/chapitre21",
      cats: ["Algorithmique et programmation"]
    },
    {},
    {}
  )} </div>`;
});
export {
  Page as default
};
