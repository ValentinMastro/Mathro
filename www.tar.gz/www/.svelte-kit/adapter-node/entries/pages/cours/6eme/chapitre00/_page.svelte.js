import { c as create_ssr_component, e as escape, v as validate_component, d as add_attribute, f as each } from "../../../../../chunks/ssr.js";
import { C as Chapitre, P as Partie, D as Definition, a as Schema, E as Exemple, S as SousPartie, b as Propriete, K as Katex } from "../../../../../chunks/Propriete.js";
const Paragraphe = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { couleur } = $$props;
  let { nom } = $$props;
  if ($$props.couleur === void 0 && $$bindings.couleur && couleur !== void 0)
    $$bindings.couleur(couleur);
  if ($$props.nom === void 0 && $$bindings.nom && nom !== void 0)
    $$bindings.nom(nom);
  return `<div style="${"color: " + escape(couleur, true) + ";"}"><u>${escape(nom)} :</u><br> ${slots.default ? slots.default({}) : ``}</div>`;
});
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: "table.svelte-rn3fpe.svelte-rn3fpe.svelte-rn3fpe{color:black;width:70vw}table.tableau.svelte-rn3fpe.svelte-rn3fpe.svelte-rn3fpe,table.tableau.svelte-rn3fpe th.svelte-rn3fpe.svelte-rn3fpe,table.tableau.svelte-rn3fpe tr.svelte-rn3fpe td.svelte-rn3fpe{border:1px solid black;border-collapse:collapse}.ligneblanche.svelte-rn3fpe.svelte-rn3fpe.svelte-rn3fpe{height:100px}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `${validate_component(Chapitre, "Chapitre").$$render(
    $$result,
    {
      numero: 0,
      titre: "Notation positionnelle des nombres"
    },
    {},
    {
      default: () => {
        return `${validate_component(Partie, "Partie").$$render($$result, { numero: 1, titre: "Chiffres et nombres" }, {}, {
          default: () => {
            return `${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
              default: () => {
                return `Pour écrire des nombres, on utilise des symboles appelés <emph data-svelte-h="svelte-iigwwm">chiffres</emph>. <br>
            Il en existe dix : 0 1 2 3 4 5 6 7 8 9 que l&#39;on peut combiner.`;
              }
            })} ${validate_component(Paragraphe, "Paragraphe").$$render($$result, { couleur: "red", nom: "Convention" }, {}, {
              default: () => {
                return `Modifier l&#39;ordre des chiffres change la valeur du nombre.`;
              }
            })} ${validate_component(Schema, "Schema").$$render(
              $$result,
              {
                fonctionAnimation: (ctx) => {
                  ctx.font = "50px serif";
                  function chiffre(digit, x1, y1, x2, y2, t2) {
                    ctx.fillText(digit, x1 * (1 - t2) + x2 * t2, y1 * (1 - t2) + y2 * t2);
                  }
                  var dt = 1 / 60;
                  var t = dt;
                  var sens = true;
                  var scenario = 0;
                  var valeur = "";
                  async function update() {
                    if (t >= 1) {
                      sens = false;
                      ctx.fillText(valeur, 0, 60);
                      await new Promise((r) => setTimeout(r, 2e3));
                    } else if (t <= 0) {
                      sens = true;
                      scenario = (scenario + 1) % 3;
                    }
                    t += sens ? dt : -dt;
                    ctx.clearRect(0, 0, 1e3, 300);
                    if (scenario == 0) {
                      chiffre("1", 30, 40, 145, 120, t);
                      chiffre("5", 130, 40, 170, 120, t);
                      chiffre("8", 230, 40, 195, 120, t);
                      valeur = "cent cinquante-huit";
                    } else if (scenario == 1) {
                      chiffre("1", 30, 40, 170, 120, t);
                      chiffre("5", 130, 40, 145, 120, t);
                      chiffre("8", 230, 40, 195, 120, t);
                      valeur = "cinq cent dix-huit";
                    } else if (scenario == 2) {
                      chiffre("1", 30, 40, 195, 120, t);
                      chiffre("5", 130, 40, 170, 120, t);
                      chiffre("8", 230, 40, 145, 120, t);
                      valeur = "huit cent cinquante-et-un";
                    }
                    requestAnimationFrame(update);
                  }
                  update();
                }
              },
              {},
              {}
            )} ${validate_component(Exemple, "Exemple").$$render($$result, { nombre: 0, exercice: void 0 }, {}, {
              default: () => {
                return `Avec les chiffres 1, 5 et 8, il est possible de former les nombres : 
            <ul data-svelte-h="svelte-qa78vt"><li>158 : cinq cinquante-huit</li> <li>185 : cinq quatre-vingt-cinq</li> <li>518 : cinq cent dix-huit</li> <li>581 : cinq cent quatre-ving-un</li> <li>815 : huit cent quinze</li> <li>851 : huit cent cinquante-et-un</li></ul>`;
              }
            })} ${validate_component(SousPartie, "SousPartie").$$render(
              $$result,
              {
                numero: 1,
                titre: "Tableau de numération"
              },
              {},
              {
                default: () => {
                  return `<table class="tableau svelte-rn3fpe"><tr data-svelte-h="svelte-12vhmsv"><th${add_attribute("colspan", 3, 0)} class="svelte-rn3fpe">Millions</th> <th${add_attribute("colspan", 3, 0)} class="svelte-rn3fpe">Milliers</th> <th${add_attribute("colspan", 3, 0)} class="svelte-rn3fpe">Unités</th></tr> <tr data-svelte-h="svelte-1gjszru"><td class="svelte-rn3fpe">Centaines</td> <td class="svelte-rn3fpe">Dizaines</td> <td class="svelte-rn3fpe">Unités</td> <td class="svelte-rn3fpe">Centaines</td> <td class="svelte-rn3fpe">Dizaines</td> <td class="svelte-rn3fpe">Unités</td> <td class="svelte-rn3fpe">Centaines</td> <td class="svelte-rn3fpe">Dizaines</td> <td class="svelte-rn3fpe">Unités</td></tr> <tr class="ligneblanche svelte-rn3fpe">${each(Array(9), (_) => {
                    return `<td class="svelte-rn3fpe"></td>`;
                  })}</tr></table>`;
                }
              }
            )} ${validate_component(SousPartie, "SousPartie").$$render(
              $$result,
              {
                numero: 2,
                titre: "Décomposition d'un nombre"
              },
              {},
              {
                default: () => {
                  return `${validate_component(Propriete, "Propriete").$$render($$result, {}, {}, {
                    default: () => {
                      return `Il est possible de décomposer un nombre selon la position de ses chiffres.`;
                    }
                  })} ${validate_component(Exemple, "Exemple").$$render($$result, { exercice: void 0, nombre: 0 }, {}, {
                    default: () => {
                      return `<tr class="svelte-rn3fpe"><td class="svelte-rn3fpe">${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                        default: () => {
                          return `45 =`;
                        }
                      })} 4 dizaines et 5 unités</td></tr> <tr class="svelte-rn3fpe"><td class="svelte-rn3fpe">${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                        default: () => {
                          return `765 =`;
                        }
                      })} 7 centaines, 6 dizaines et 5 unités</td></tr> <tr class="svelte-rn3fpe"><td class="svelte-rn3fpe">${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                        default: () => {
                          return `1~350 =`;
                        }
                      })} 1 millier, 3 centaines et 5 dizaines</td></tr> <tr class="svelte-rn3fpe"><td class="svelte-rn3fpe">${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                        default: () => {
                          return `29~543 =`;
                        }
                      })} 2 dizaines de milliers, 9 milliers, 5 centaines, 4 dizaines et 3 dizaines</td></tr>`;
                    }
                  })}`;
                }
              }
            )}`;
          }
        })} ${validate_component(Partie, "Partie").$$render($$result, { numero: 2, titre: "Comparaison" }, {}, {})}`;
      }
    }
  )}`;
});
export {
  Page as default
};
