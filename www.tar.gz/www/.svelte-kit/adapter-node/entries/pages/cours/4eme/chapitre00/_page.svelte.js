import { c as create_ssr_component, v as validate_component } from "../../../../../chunks/ssr.js";
import { C as Chapitre, P as Partie, S as SousPartie, D as Definition, E as Exemple, a as Schema, b as Propriete, K as Katex } from "../../../../../chunks/Propriete.js";
import { E as EstEntierNaturel, a as EstEntierRelatif, b as EstNombreRationnel } from "../../../../../chunks/ch00.js";
const css = {
  code: "div.svelte-1xnisf3{color:black}",
  map: null
};
const Remarque = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<div class="svelte-1xnisf3"><u data-svelte-h="svelte-wv7ya6">Remarque :</u><br> ${slots.default ? slots.default({}) : ``} </div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(Chapitre, "Chapitre").$$render($$result, { numero: 0, titre: "Opérations" }, {}, {
    default: () => {
      return `${validate_component(Partie, "Partie").$$render($$result, { numero: 1, titre: "Les nombres" }, {}, {
        default: () => {
          return `${validate_component(SousPartie, "SousPartie").$$render($$result, { numero: 1, titre: "Nombres entiers" }, {}, {
            default: () => {
              return `${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                default: () => {
                  return `Un nombre <i data-svelte-h="svelte-tahb3m">entier naturel</i> permet de compter des éléments. 
                Il est positif et n&#39;a pas de partie décimale.`;
                }
              })} ${validate_component(Exemple, "Exemple").$$render(
                $$result,
                {
                  exercice: new EstEntierNaturel(),
                  nombre: 3
                },
                {},
                {}
              )} ${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                default: () => {
                  return `Un nombre <i data-svelte-h="svelte-zwlyz6">entier relatif</i> n&#39;a pas de partie décimale et 
                peut être positif comme négatif.`;
                }
              })} ${validate_component(Exemple, "Exemple").$$render(
                $$result,
                {
                  exercice: new EstEntierRelatif(),
                  nombre: 3
                },
                {},
                {}
              )} ${validate_component(Remarque, "Remarque").$$render($$result, {}, {}, {
                default: () => {
                  return `0 est considéré comme un nombre négatif <u data-svelte-h="svelte-ugzwhv">et</u> positif.`;
                }
              })}`;
            }
          })} ${validate_component(SousPartie, "SousPartie").$$render(
            $$result,
            {
              numero: 2,
              titre: "Fractions et nombres rationnels"
            },
            {},
            {
              default: () => {
                return `${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                  default: () => {
                    return `Une fraction est un moyen d&#39;écrire le résultat d&#39;une division entre 
                deux nombres entiers : le numérateur et le dénominateur.`;
                  }
                })} ${validate_component(Schema, "Schema").$$render(
                  $$result,
                  {
                    fonctionAnimation: (context) => {
                      context.scale(2, 2);
                      context.font = "16px sans-serif";
                      context.textBaseline = "middle";
                      context.textAlign = "center";
                      var [x, y] = [3, 4];
                      var [t, total, envers] = [0, 60, true];
                      async function update() {
                        if (t >= total || t <= 0) {
                          envers = !envers;
                          await new Promise((r) => setTimeout(r, 2e3));
                        }
                        t = t + (envers ? -1 : 1);
                        context.clearRect(0, 0, 300, 300);
                        context.fillText(x.toString(), 200 + (180 - 200) * (t / total), 25 + (35 - 25) * (t / total));
                        context.fillText(y.toString(), 200 + (220 - 200) * (t / total), 45 + (35 - 45) * (t / total));
                        context.fill();
                        context.beginPath();
                        context.moveTo(190, 35);
                        context.lineTo(210, 35);
                        context.stroke();
                        if (t > 0.15 * total) {
                          context.beginPath();
                          context.arc(200, 25, 1.7, 0, 2 * Math.PI);
                          context.fill();
                          context.beginPath();
                          context.arc(200, 45, 1.7, 0, 2 * Math.PI);
                          context.fill();
                        }
                        requestAnimationFrame(update);
                      }
                      update();
                    }
                  },
                  {},
                  {}
                )} ${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                  default: () => {
                    return `S&#39;il existe une division entre deux nombres entiers 
                égale à un nombre,
                alors ce nombre est <i data-svelte-h="svelte-1qbjdns">rationnel</i>.`;
                  }
                })} ${validate_component(Exemple, "Exemple").$$render(
                  $$result,
                  {
                    exercice: new EstNombreRationnel(),
                    nombre: 3
                  },
                  {},
                  {}
                )}`;
              }
            }
          )} ${validate_component(SousPartie, "SousPartie").$$render($$result, { numero: 3, titre: "Les nombres décimaux" }, {}, {
            default: () => {
              return `${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                default: () => {
                  return `Une fraction décimale est une fraction 
                dont le dénominateur est égal à 1, 10, 100, 1000, etc.`;
                }
              })} ${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                default: () => {
                  return `Un nombre décimal est un nombre qui peut s&#39;écrire 
                sous forme d&#39;une fraction décimale.`;
                }
              })}`;
            }
          })}`;
        }
      })} ${validate_component(Partie, "Partie").$$render($$result, { numero: 2, titre: "Opérations" }, {}, {
        default: () => {
          return `${validate_component(SousPartie, "SousPartie").$$render($$result, { numero: 1, titre: "Addition" }, {}, {
            default: () => {
              return `${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                default: () => {
                  return `L&#39;addition décrit la réunion de deux quantités. 
                Elle est notée avec le symbole +, 
                les deux nombres additionnés sont les <i data-svelte-h="svelte-sd5rm2">termes</i> et 
                le résultat est appelé la <i data-svelte-h="svelte-1g6zj5d">somme</i>.`;
                }
              })} ${validate_component(Propriete, "Propriete").$$render($$result, {}, {}, {
                default: () => {
                  return `La somme ne dépend pas de l&#39;ordre des termes.<br>
                (On dit que l&#39;addition est <i data-svelte-h="svelte-dwloi0">commutative</i>.)`;
                }
              })} ${validate_component(Propriete, "Propriete").$$render($$result, {}, {}, {
                default: () => {
                  return `Pour additionner deux nombres relatifs :
                <ul data-svelte-h="svelte-yh7lud"><li>s&#39;ils sont de même signe, 
                        la somme a le même signe et 
                        on additionne les distances à zéro ;</li> <li>s&#39;ils sont de signes différents, 
                        le signe de la somme est celui du terme de la 
                        plus grande distance à zéro, 
                        et on soustrait les distances à zéro.</li></ul>`;
                }
              })}`;
            }
          })} ${validate_component(SousPartie, "SousPartie").$$render($$result, { numero: 2, titre: "Soustraction" }, {}, {
            default: () => {
              return `${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                default: () => {
                  return `La soustraction décrit le retranchement d&#39;une quantité 
                à une autre. Elle est notée avec le symbole -, 
                les deux nombres sont les <i data-svelte-h="svelte-sd5rm2">termes</i> et le résultat est 
                appelé la <i data-svelte-h="svelte-1x76i5h">différence</i>.`;
                }
              })} ${validate_component(Propriete, "Propriete").$$render($$result, {}, {}, {
                default: () => {
                  return `Soustraire un nombre revient à ajouter son opposé.`;
                }
              })}`;
            }
          })} ${validate_component(SousPartie, "SousPartie").$$render($$result, { numero: 3, titre: "Multiplication" }, {}, {
            default: () => {
              return `${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                default: () => {
                  return `La multiplication est la répétition successive d&#39;une addition. 
                Les nombres multipliés sont les <i data-svelte-h="svelte-rhlr9p">facteurs</i> 
                et le résultat est appelé le <i data-svelte-h="svelte-1qvq2bn">produit</i>.`;
                }
              })} ${validate_component(Propriete, "Propriete").$$render($$result, {}, {}, {
                default: () => {
                  return `Le produit ne dépend pas de l&#39;ordre des facteurs.<br>
                (On dit que la multiplication est <i data-svelte-h="svelte-dwloi0">commutative</i>)`;
                }
              })} ${validate_component(Propriete, "Propriete").$$render($$result, {}, {}, {
                default: () => {
                  return `Pour multiplier des nombres relatifs :
                <ul data-svelte-h="svelte-p5sgh9"><li>si le nombre de <i>facteurs négatifs</i> est impair,
                    le produit est négatif ;</li> <li>si le nombre de <i>facteurs négatifs</i> est pair,
                    le produit est positif.</li></ul>`;
                }
              })}`;
            }
          })} ${validate_component(SousPartie, "SousPartie").$$render($$result, { numero: 4, titre: "Division" }, {}, {
            default: () => {
              return `${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                default: () => {
                  return `La division permet de séparer en plusieurs parts égales une quantité. 
                On divise le <i data-svelte-h="svelte-kirvxw">dividende</i> par le <i data-svelte-h="svelte-4yg763">diviseur</i> 
                afin d&#39;obtenir le <i data-svelte-h="svelte-1ce7qlb">quotient</i>.
                <br>
                Les symboles utilisés pour la division sont :
                <ul data-svelte-h="svelte-14zxkw6"><li>les deux-points « : » ;</li> <li>le <i>slash</i> « / »</li> <li>l&#39;obélus « ÷ »</li></ul>`;
                }
              })}`;
            }
          })} ${validate_component(SousPartie, "SousPartie").$$render($$result, { numero: 5, titre: "Modulo" }, {}, {
            default: () => {
              return `${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                default: () => {
                  return `À deux entiers naturels ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                    default: () => {
                      return `a`;
                    }
                  })} et ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                    default: () => {
                      return `b`;
                    }
                  })}, ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                    default: () => {
                      return `b`;
                    }
                  })} non nul, on associe deux entiers 
                naturels : le quotient ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                    default: () => {
                      return `q`;
                    }
                  })} et le reste ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                    default: () => {
                      return `r`;
                    }
                  })} tels que :
                ${validate_component(Katex, "Katex").$$render($$result, { displayMode: true }, {}, {
                    default: () => {
                      return `a = b \\times q + r`;
                    }
                  })}`;
                }
              })} ${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                default: () => {
                  return `« ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                    default: () => {
                      return `a`;
                    }
                  })} modulo ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                    default: () => {
                      return `b`;
                    }
                  })} », noté ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                    default: () => {
                      return `a~\\%~b`;
                    }
                  })}, est le reste 
                de la division euclidienne de ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                    default: () => {
                      return `a`;
                    }
                  })} par ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                    default: () => {
                      return `b`;
                    }
                  })}.`;
                }
              })}`;
            }
          })}`;
        }
      })} ${validate_component(Partie, "Partie").$$render(
        $$result,
        {
          numero: 3,
          titre: "Priorités opératoires"
        },
        {},
        {
          default: () => {
            return `${validate_component(Propriete, "Propriete").$$render($$result, {}, {}, {
              default: () => {
                return `Dans un calcul contenant plusieurs opérations :
            <ul data-svelte-h="svelte-et01u2"><li>la priorité est donnée aux calculs entres parenthèses</li> <li>puis, aux multiplications et aux divisions (de gauche à droite)</li> <li>enfin, aux additions et aux soustractions (de gauche à droite)</li></ul>`;
              }
            })} ${validate_component(Remarque, "Remarque").$$render($$result, {}, {}, {
              default: () => {
                return `Dans un calcul contenant un trait de fraction, on calcule d&#39;abord le 
            numérateur et le dénominateur, puis on effectue la division.`;
              }
            })}`;
          }
        }
      )}`;
    }
  })}`;
});
export {
  Page as default
};
