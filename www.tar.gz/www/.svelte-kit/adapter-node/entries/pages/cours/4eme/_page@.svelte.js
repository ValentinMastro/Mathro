import { c as create_ssr_component, v as validate_component } from "../../../../chunks/ssr.js";
import { M as MenuChapitre } from "../../../../chunks/MenuChapitre.js";
const _page__svelte_svelte_type_style_lang = "";
const css = {
  code: 'div#menu.svelte-e6s43z.svelte-e6s43z{display:flex;flex-direction:row;flex-wrap:wrap;justify-content:space-evenly;row-gap:50px}ol.svelte-e6s43z.svelte-e6s43z{padding:10px}ol.svelte-e6s43z li.svelte-e6s43z{list-style-type:none;counter-increment:step-counter}ol.svelte-e6s43z li.svelte-e6s43z:before{content:counter(step-counter, upper-roman) " - "}',
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `${$$result.head += `<!-- HEAD_svelte-1c9wf1w_START -->${$$result.title = `<title>Cours : 4ème</title>`, ""}<meta name="description" content="Cours de quatrième"><!-- HEAD_svelte-1c9wf1w_END -->`, ""} <div id="menu" class="svelte-e6s43z">${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 0,
      titre: "Opérations",
      url: "/cours/4eme/chapitre00",
      cats: ["Nombres et calculs"],
      img: "/images/Euclide.jpg"
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-1on95w0"><li class="svelte-e6s43z">Natures des nombres</li> <li class="svelte-e6s43z">Les 5 opérations de bases</li> <li class="svelte-e6s43z">La priorité des opérations</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 1,
      titre: "Théorème de Pythagore",
      url: "/cours/4eme/chapitre01",
      cats: ["Espace et géométrie", "Grandeurs et mesures"],
      img: "/images/Pythagoras.jpg"
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-qn4qct"><li class="svelte-e6s43z">Carré et racine carrée</li> <li class="svelte-e6s43z">Triangle rectangle et hypoténuse</li> <li class="svelte-e6s43z">Énoncé et application du théorème</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 2,
      titre: "Fractions et proportionnalité",
      url: "/cours/4eme/chapitre00",
      cats: ["Nombres et calculs"],
      img: "/images/gateau.png"
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-1smn8e"><li class="svelte-e6s43z">Calculs fractionnaires</li> <li class="svelte-e6s43z">Pourcentages</li> <li class="svelte-e6s43z">Échelle</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 3,
      titre: "Solides de l'espace",
      url: "/cours/4eme/chapitre00",
      cats: ["Espace et géométrie", "Grandeurs et mesures"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-t2v0fl"><li class="svelte-e6s43z">Volume et contenance</li> <li class="svelte-e6s43z">Solides de l&#39;espace</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 4,
      titre: "Calcul littéral",
      url: "/cours/4eme/chapitre00",
      cats: ["Nombres et calculs"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-bo858d"><li class="svelte-e6s43z">Expression littérale</li> <li class="svelte-e6s43z">Développer, factoriser et réduire</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 5,
      titre: "Théorème de Thalès",
      url: "/cours/4eme/chapitre00",
      cats: ["Espace et géométrie", "Grandeurs et calculs"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-u8it6c"><li class="svelte-e6s43z">Angles et parallélisme</li> <li class="svelte-e6s43z">Énoncé</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 6,
      titre: "Puissances",
      url: "/cours/4eme/chapitre00",
      cats: ["Nombres et calculs"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-fsojd7"><li class="svelte-e6s43z">Les puissances de 10</li> <li class="svelte-e6s43z">Puissances à base quelconque</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 7,
      titre: "Statistiques",
      url: "/cours/4eme/chapitre00",
      cats: ["Organisation et gestion de données"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-1siocrj"><li class="svelte-e6s43z">Indicateurs de position</li> <li class="svelte-e6s43z">Diagrammes et graphiques</li> <li class="svelte-e6s43z">Fréquences</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 8,
      titre: "Cosinus",
      url: "/cours/4eme/chapitre00",
      cats: ["Espace et géométrie", "Grandeurs et mesures"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-j4z4y"><li class="svelte-e6s43z">Les côtés dans un triangle rectangle</li> <li class="svelte-e6s43z">Cosinus d&#39;un angle</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 9,
      titre: "Équation",
      url: "/cours/4eme/chapitre00",
      cats: ["Nombres et calculs"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-qwpipj"><li class="svelte-e6s43z">Concept</li> <li class="svelte-e6s43z">Résolutions d&#39;équations du premier degré</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 10,
      titre: "Probabilités",
      url: "/cours/4eme/chapitre00",
      cats: ["Organisation et gestion de données"]
    },
    {},
    {}
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 11,
      titre: "Transformations du plan",
      url: "/cours/4eme/chapitre00",
      cats: ["Espace et géométrie"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-ffusrk"><li class="svelte-e6s43z">Symétrie axiale</li> <li class="svelte-e6s43z">Symétrie centrale</li> <li class="svelte-e6s43z">Translation</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 12,
      titre: "Décompositions en facteurs premiers",
      url: "/cours/4eme/chapitre00",
      cats: ["Nombres et calculs"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-1hv17l2"><li class="svelte-e6s43z">Les nombres premiers</li> <li class="svelte-e6s43z">Théorème fondamental de l&#39;arithmétique</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 13,
      titre: "Repérage sur un pavé droit",
      url: "/cours/4eme/chapitre00",
      cats: ["Espace et géométrie"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-j37im0"><li class="svelte-e6s43z">Sur une droite (1 dimension)</li> <li class="svelte-e6s43z">Sur un plan (2 dimensions)</li> <li class="svelte-e6s43z">Dans l&#39;espace, sur un pavé droit (3 dimensions)</li></ol>`;
      }
    }
  )} ${validate_component(MenuChapitre, "MenuChapitre").$$render(
    $$result,
    {
      index: 14,
      titre: "Réciproques",
      url: "cours/4eme/chapitre14",
      cats: ["Espace et géométrie", "Grandeurs et mesures"]
    },
    {},
    {
      default: () => {
        return `<ol class="svelte-e6s43z" data-svelte-h="svelte-16v2djj"><li class="svelte-e6s43z">Réciproque du théorème de Thalès</li> <li class="svelte-e6s43z">Réciproque du théorème de Pythagore</li></ol>`;
      }
    }
  )} </div>`;
});
export {
  Page as default
};
