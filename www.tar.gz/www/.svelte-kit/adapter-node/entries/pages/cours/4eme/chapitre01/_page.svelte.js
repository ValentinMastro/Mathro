import { c as create_ssr_component, e as escape, v as validate_component } from "../../../../../chunks/ssr.js";
import { C as Chapitre, P as Partie, S as SousPartie, D as Definition, a as Schema, E as Exemple, K as Katex, b as Propriete } from "../../../../../chunks/Propriete.js";
import { E as Exercice, N as Nombre, P as Parmi, L as Lettre } from "../../../../../chunks/types.js";
const Theoreme_svelte_svelte_type_style_lang = "";
const css$1 = {
  code: "div.svelte-1i1hglf{color:red}",
  map: null
};
const Theoreme = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { titre } = $$props;
  if ($$props.titre === void 0 && $$bindings.titre && titre !== void 0)
    $$bindings.titre(titre);
  $$result.css.add(css$1);
  return `<div class="svelte-1i1hglf"><u>${escape(titre)} :</u><br> ${slots.default ? slots.default({}) : ``} </div>`;
});
class Calculer_le_carre_d_un_nombre extends Exercice {
  gen;
  n;
  constructor(gen = new Nombre(-5, 12)) {
    super();
    this.gen = gen;
    this.n = this.gen.valeur();
  }
  est_reponse_valide(valeur) {
    return valeur == Math.pow(this.n, 2);
  }
  est_reponse_invalide(valeur) {
    return valeur != Math.pow(this.n, 2);
  }
  vraifaux() {
    this.n = this.gen.valeur();
    var x = new Parmi([this.n * 2, Math.pow(this.n, 2), this.n + 2]).valeur();
    this.enonce = `${x} est-il le carré de ${this.n} ?`;
    this.bonne_reponse = this.est_reponse_valide(x);
  }
  qcm(nombre_reponses = 5) {
    this.nombre_reponses = nombre_reponses;
    this.n = this.gen.valeur();
    this.enonce = `<Katex>${this.n >= 0 ? "(" : ""}${this.n}${this.n >= 0 ? ")" : ""}^2 =</Katex>`;
    this.bonne_reponse = Math.pow(this.n, 2);
    var propositions = new Parmi([]);
    this.mauvaises_reponses = propositions.multiple_jusquà(
      this.nombre_reponses - 1,
      this.est_reponse_invalide
    );
  }
  exemple_unitaire() {
    this.n = this.gen.valeur();
    var output = [];
    var nombre = `${this.n <= 0 ? "(" : ""}${this.n}${this.n <= 0 ? ")" : ""}`;
    output.push({
      type: "formule",
      valeur: nombre + `^2 = ${nombre} \\times ${nombre} = ${Math.pow(this.n, 2)}`
    });
    return output;
  }
}
class Calculer_la_racine_carree_d_un_nombre extends Exercice {
  gen;
  n;
  // Le nombre dont on cherche la racine carrée
  constructor(gen = new Nombre(1, 12, 0, (nombre) => {
    return Math.pow(nombre, 2);
  })) {
    super();
    this.gen = gen;
    this.n = this.gen.valeur();
  }
  est_reponse_valide(valeur) {
    return valeur == Math.sqrt(this.n);
  }
  est_reponse_invalide(valeur) {
    return valeur != Math.sqrt(this.n);
  }
  qcm(nombre_reponses = 5) {
    this.nombre_reponses = nombre_reponses;
    this.n = this.gen.valeur();
    this.enonce = `<Katex>\\sqrt{${this.n}} = ?</Katex>`;
    this.bonne_reponse = Math.sqrt(this.n);
    var propositions = new Parmi([]);
    this.mauvaises_reponses = propositions.multiple_jusquà(
      this.nombre_reponses - 1,
      this.est_reponse_invalide
    );
  }
  exemple_unitaire() {
    this.n = this.gen.valeur();
    return [{
      type: "formule",
      valeur: `\\sqrt{${this.n}} = ${Math.sqrt(this.n)}`
    }];
  }
}
class Egalite_de_pythagore extends Exercice {
  points;
  index;
  // L'index du point où se situe l'angle droit (0, 1 ou 2)
  constructor() {
    super();
    this.points = new Lettre().multiple(3);
    this.index = new Nombre(0, 2);
  }
  exemple_unitaire() {
    var index = this.index.valeur();
    this.points = new Lettre().multiple(3).map((l) => {
      return `{\\rm ${l}}`;
    });
    var [p1, p2, p3] = this.points;
    var [c1, c2, c3] = [
      this.points[(index - 1 + 3) % 3] + this.points[(index + 1 + 3) % 3],
      this.points[index] + this.points[(index + 1 + 3) % 3],
      this.points[(index - 1 + 3) % 3] + this.points[index]
    ];
    return [{
      type: "formule",
      valeur: `\\text{Si}~${p1 + p2 + p3}~\\text{est rectangle en}~${this.points[index]}, \\text{alors : }${c3}^2 + ${c2}^2 = ${c1}^2`
    }];
  }
}
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: "div.Redaction.svelte-vmbp2h{color:blue;border-width:2px;border-color:red}div#énoncé.svelte-vmbp2h{background-color:yellow;text-align:center}div#réponse.svelte-vmbp2h{background-color:white}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `${validate_component(Chapitre, "Chapitre").$$render(
    $$result,
    {
      numero: 1,
      titre: "Théorème de Pythagore"
    },
    {},
    {
      default: () => {
        return `${validate_component(Partie, "Partie").$$render(
          $$result,
          {
            numero: 1,
            titre: "Carré et racine carrée"
          },
          {},
          {
            default: () => {
              return `${validate_component(SousPartie, "SousPartie").$$render($$result, { numero: 1, titre: "Le carré d'un nombre" }, {}, {
                default: () => {
                  return `${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                    default: () => {
                      return `Le carré d&#39;un nombre est égal à ce nombre multiplié par lui-même.
                On le note avec un « 2 » en exposant (en petit, en haut à droite).`;
                    }
                  })} ${validate_component(Schema, "Schema").$$render(
                    $$result,
                    {
                      fonctionAnimation: (context) => {
                        context.font = "48px serif";
                        context.textBaseline = "middle";
                        var n = 2;
                        var taille = 0;
                        var ecart = 0;
                        async function update() {
                          n += 1;
                          if (n > 12) {
                            n = 3;
                          }
                          taille = 22 - n;
                          ecart = taille / 5;
                          await new Promise((r) => setTimeout(r, 2e3));
                          context.clearRect(0, 0, 1e3, 300);
                          context.textAlign = "end";
                          context.fillText(`${n} =`, 95, 80);
                          for (var i = 0; i < n; i++) {
                            context.fillRect(100 + (taille + ecart) * i, 77 - taille / 2, taille, taille);
                          }
                          context.fillRect(450, 0, 1, 180);
                          context.fillText(`${n}² = `, 585, 80);
                          for (var i = 0; i < n * n; i++) {
                            context.fillRect(580 + (taille + ecart) * (i % n), 77 - taille / 2 + (taille + ecart) * (Math.floor(i / n) - (n - 1) / 2), taille, taille);
                          }
                          context.textAlign = "left";
                          context.fillText(`= ${n * n}`, 580 + (taille + ecart) * n, 80);
                          requestAnimationFrame(update);
                        }
                        update();
                      }
                    },
                    {},
                    {}
                  )} ${validate_component(Exemple, "Exemple").$$render(
                    $$result,
                    {
                      exercice: new Calculer_le_carre_d_un_nombre(),
                      nombre: 3
                    },
                    {},
                    {}
                  )} ${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                    default: () => {
                      return `La racine carrée est l&#39;opération réciproque du calcul du carré d&#39;un nombre.
                Elle se note avec le symbole « radical » : ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                        default: () => {
                          return `\\sqrt${escape("{~~}")}`;
                        }
                      })}.`;
                    }
                  })} ${validate_component(Exemple, "Exemple").$$render(
                    $$result,
                    {
                      exercice: new Calculer_la_racine_carree_d_un_nombre(),
                      nombre: 1
                    },
                    {},
                    {
                      default: () => {
                        return `<tr>Si le carré de 12 est 144, ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                          default: () => {
                            return `${escape("\\sqrt{144}=12")}`;
                          }
                        })}</tr> <tr>Si ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                          default: () => {
                            return `${escape("8^2=64")}`;
                          }
                        })} alors ${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                          default: () => {
                            return `${escape("\\sqrt{64}=8")}`;
                          }
                        })}</tr>`;
                      }
                    }
                  )}`;
                }
              })}`;
            }
          }
        )} ${validate_component(Partie, "Partie").$$render(
          $$result,
          {
            numero: 2,
            titre: "Triangle rectangle et hypoténuse"
          },
          {},
          {
            default: () => {
              return `${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                default: () => {
                  return `Un triangle rectangle est une figure à 3 côtés possédant un angle droit (${validate_component(Katex, "Katex").$$render($$result, {}, {}, {
                    default: () => {
                      return `=90°`;
                    }
                  })}).`;
                }
              })} ${validate_component(Definition, "Definition").$$render($$result, {}, {}, {
                default: () => {
                  return `L&#39;hypoténuse d&#39;un triangle rectangle est le côté opposé à l&#39;angle droit.`;
                }
              })} ${validate_component(Propriete, "Propriete").$$render($$result, {}, {}, {
                default: () => {
                  return `L&#39;hypoténuse est le côté le plus grand d&#39;un triangle rectangle.`;
                }
              })} ${validate_component(Schema, "Schema").$$render(
                $$result,
                {
                  fonctionAnimation: (ctx) => {
                    var [x, y, z, t] = [140, 20, 45, 120];
                    ctx.beginPath();
                    ctx.moveTo(x, t);
                    ctx.lineTo(x, y);
                    ctx.lineTo(z, t);
                    ctx.closePath();
                    ctx.stroke();
                    ctx.font = "20px serif";
                    ctx.textAlign = "center";
                    ctx.textBaseline = "middle";
                    ctx.fillText("A", x + 10, t + 3);
                    ctx.fillText("B", z - 15, t + 3);
                    ctx.fillText("C", x + 10, y);
                    ctx.fillRect(x, t, -10, -10);
                  }
                },
                {},
                {}
              )}`;
            }
          }
        )} ${validate_component(Partie, "Partie").$$render(
          $$result,
          {
            numero: 3,
            titre: "Énoncé et application du théorème de Pythagore"
          },
          {},
          {
            default: () => {
              return `${validate_component(Theoreme, "Theoreme").$$render($$result, { titre: "Théorème de Pythagore" }, {}, {
                default: () => {
                  return `Si un triangle est rectangle, alors le carré de la longueur de l&#39;hypoténuse
            est égal à la somme des carrés des longueurs des deux autres côtés. <br>`;
                }
              })} ${validate_component(Exemple, "Exemple").$$render(
                $$result,
                {
                  exercice: new Egalite_de_pythagore(),
                  nombre: 3
                },
                {},
                {}
              )} ${validate_component(Schema, "Schema").$$render(
                $$result,
                {
                  fonctionAnimation: (ctx) => {
                    var [x, y, z, t] = [140, 20, 45, 120];
                    var d = Math.pow(t - y, 2) + Math.pow(z - x, 2);
                    var [sens_t, sens_z] = [true, true];
                    async function update() {
                      if (t > 140 || t <= z) {
                        sens_t = !sens_t;
                      }
                      t += sens_t ? 1 : -1;
                      await new Promise((r) => setTimeout(r, 100));
                      ctx.clearRect(0, 0, 600, 200);
                      ctx.beginPath();
                      ctx.moveTo(x, t);
                      ctx.lineTo(x, y);
                      ctx.lineTo(z, t);
                      ctx.closePath();
                      ctx.stroke();
                      ctx.font = "20px serif";
                      ctx.textAlign = "center";
                      ctx.textBaseline = "middle";
                      ctx.fillText("A", x + 10, t + 3);
                      ctx.fillText("B", z - 15, t + 3);
                      ctx.fillText("C", x + 10, y);
                      ctx.fillRect(x, t, -10, -10);
                      ctx.textAlign = "left";
                      d = Math.pow(t - y, 2) + Math.pow(z - x, 2);
                      ctx.fillText(`AB² + AC² = ${d}`, 350, 50);
                      ctx.fillText(`BC² = ${d}`, 350, 80);
                      requestAnimationFrame(update);
                    }
                    update();
                  }
                },
                {},
                {}
              )} <div class="Redaction svelte-vmbp2h"><u data-svelte-h="svelte-5bzbkm">Exemple de rédaction :</u> <div id="énoncé" class="svelte-vmbp2h" data-svelte-h="svelte-1rad4ix">Soit DEF un triangle rectangle en E, tel que DE = 6 cm et EF = 8 cm.<br>
                Calculer la longueur DF.</div> <div id="réponse" class="svelte-vmbp2h">${validate_component(Katex, "Katex").$$render($$result, {}, {}, {})} <div data-svelte-h="svelte-1ap9s2v">On sait que : le triangle DEF est rectangle en E,
                donc l&#39;hypoténuse est [DF]</div> <div data-svelte-h="svelte-11ojoxc">D&#39;après le théorème de Pythagore</div> <div data-svelte-h="svelte-19c4nwu">DE²+EF² = DF²</div></div></div>`;
            }
          }
        )}`;
      }
    }
  )}`;
});
export {
  Page as default
};
