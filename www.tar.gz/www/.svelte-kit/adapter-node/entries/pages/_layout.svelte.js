import { c as create_ssr_component, b as subscribe, v as validate_component } from "../../chunks/ssr.js";
import { p as page } from "../../chunks/stores.js";
const Header_svelte_svelte_type_style_lang = "";
const css$1 = {
  code: "header.svelte-11d91ll{display:flex;justify-content:space-between}nav.svelte-11d91ll{display:flex;flex-direction:column;justify-content:space-evenly;--size:max(3vh, 3vw);width:--size;height:--size}div.svelte-11d91ll{width:30px;height:5px;background-color:white;margin:3px 0}",
  map: null
};
const Header = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css$1);
  return `<header class="svelte-11d91ll" data-svelte-h="svelte-gj2dy4"><a href="/" data-sveltekit-reload><nav class="svelte-11d91ll"><div class="svelte-11d91ll"></div> <div class="svelte-11d91ll"></div> <div class="svelte-11d91ll"></div></nav></a> </header>`;
});
const accueil = "";
const _layout_svelte_svelte_type_style_lang = "";
const css = {
  code: ".app.svelte-1yfjnyv{display:flex;flex-direction:column;min-height:100vh}main.svelte-1yfjnyv{flex:1;display:flex;flex-direction:column;width:85%;max-width:85rem;margin:0 auto;box-sizing:border-box}",
  map: null
};
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $page, $$unsubscribe_page;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  $$result.css.add(css);
  $$unsubscribe_page();
  return `${$page.url.pathname === "/" ? `<div class="app svelte-1yfjnyv">${slots.default ? slots.default({}) : ``}</div>` : `${$page.url.pathname === "/cours/4eme" || $page.url.pathname === "/cours/6eme" ? `<div class="app svelte-1yfjnyv">${validate_component(Header, "Header").$$render($$result, {}, {}, {})} ${slots.default ? slots.default({}) : ``}</div>` : `<div class="app svelte-1yfjnyv">${validate_component(Header, "Header").$$render($$result, {}, {}, {})} <main class="svelte-1yfjnyv">${slots.default ? slots.default({}) : ``}</main></div>`}`}`;
});
export {
  Layout as default
};
