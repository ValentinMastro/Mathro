import { c as create_ssr_component } from "../../chunks/ssr.js";
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: "div#accueil.svelte-1smqdyf.svelte-1smqdyf{display:flex;flex-direction:row;align-items:center;justify-content:center;height:100vh}div#sigma.svelte-1smqdyf.svelte-1smqdyf{font-size:30vw}div#sigma.svelte-1smqdyf:hover+div#menu.svelte-1smqdyf{display:block}div.niveau.svelte-1smqdyf.svelte-1smqdyf{font-size:5vw;margin-left:1em}a.svelte-1smqdyf.svelte-1smqdyf{text-decoration:none}@media(max-aspect-ratio: 1){div#accueil.svelte-1smqdyf.svelte-1smqdyf{flex-direction:column}div#sigma.svelte-1smqdyf.svelte-1smqdyf{font-size:30vh}div.niveau.svelte-1smqdyf.svelte-1smqdyf{margin:0;font-size:5vh}}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `${$$result.head += `<!-- HEAD_svelte-1kqvix2_START -->${$$result.title = `<title>Accueil</title>`, ""}<meta name="description" content="Cours et exercices de mathématiques"><!-- HEAD_svelte-1kqvix2_END -->`, ""} <div id="accueil" class="svelte-1smqdyf" data-svelte-h="svelte-19zbcw"><div id="sigma" class="svelte-1smqdyf">Σ</div> <div id="menu" data-sveltekit-reload class="svelte-1smqdyf"><div id="4eme" class="niveau svelte-1smqdyf"><a href="/cours/4eme" class="svelte-1smqdyf">4ème</a></div> <div id="6eme" class="niveau svelte-1smqdyf"><a href="/cours/6eme" class="svelte-1smqdyf">6ème</a></div></div> </div>`;
});
export {
  Page as default
};
