import { c as create_ssr_component, e as escape, v as validate_component } from "../../../chunks/ssr.js";
import { a as EstEntierRelatif } from "../../../chunks/ch00.js";
const Exercice_svelte_svelte_type_style_lang = "";
const css = {
  code: "h2.enonce.svelte-l03y9{font-size:4vh;user-select:none}div.schema.svelte-l03y9{height:50vh}div#vraifaux.svelte-l03y9{display:flex;flex-direction:row;justify-content:space-between}button.reponse.svelte-l03y9{width:45%;font-size:5vh;text-align:center;user-select:none}button.choix.svelte-l03y9{background-color:orange}span.svelte-l03y9{width:100%;text-align:center}",
  map: null
};
const Exercice = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let ex = new EstEntierRelatif();
  let data = ex.afficher_vraifaux();
  $$result.css.add(css);
  return `${data["type"] == "VraiFaux" ? `<h2 class="enonce svelte-l03y9">${escape(data["enonce"])}</h2> <div class="schema svelte-l03y9"></div> <div id="vraifaux" class="svelte-l03y9"><button id="vrai" class="${"reponse " + escape("", true) + " svelte-l03y9"}"><span class="svelte-l03y9" data-svelte-h="svelte-1dup7as">VRAI</span></button> <button id="faux" class="${"reponse " + escape("", true) + " svelte-l03y9"}"><span class="svelte-l03y9" data-svelte-h="svelte-4fajju">FAUX</span></button></div>` : `${data["type"] == "QCM" ? `<h2 class="enonce svelte-l03y9">${escape(data["enonce"])}</h2>` : ``}`}`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return ` ${$$result.head += `<!-- HEAD_svelte-18lvto8_START -->${$$result.title = `<title>Sverdle</title>`, ""}<meta name="description" content="A Wordle clone written in SvelteKit"><!-- HEAD_svelte-18lvto8_END -->`, ""} ${validate_component(Exercice, "Exercice").$$render($$result, {}, {}, {})}`;
});
export {
  Page as default
};
