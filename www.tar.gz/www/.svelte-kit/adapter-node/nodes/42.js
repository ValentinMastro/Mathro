

export const index = 42;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/exercices/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/42.94f1066c.js","_app/immutable/chunks/scheduler.2cdf953d.js","_app/immutable/chunks/index.cba2a906.js","_app/immutable/chunks/ch00.8f3986eb.js","_app/immutable/chunks/types.02c09cd6.js"];
export const stylesheets = ["_app/immutable/assets/42.b29c6456.css"];
export const fonts = [];
