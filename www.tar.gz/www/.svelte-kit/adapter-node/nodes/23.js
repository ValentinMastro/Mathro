

export const index = 23;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/cours/6eme/chapitre02/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/23.4b254382.js","_app/immutable/chunks/scheduler.2cdf953d.js","_app/immutable/chunks/index.cba2a906.js"];
export const stylesheets = [];
export const fonts = [];
