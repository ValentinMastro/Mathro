

export const index = 20;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/cours/6eme/_page@.svelte.js')).default;
export const imports = ["_app/immutable/nodes/20.fd4344d2.js","_app/immutable/chunks/scheduler.2cdf953d.js","_app/immutable/chunks/index.cba2a906.js","_app/immutable/chunks/MenuChapitre.1749b445.js","_app/immutable/chunks/each.e59479a4.js"];
export const stylesheets = ["_app/immutable/assets/4.744b922c.css","_app/immutable/assets/MenuChapitre.9dcc3d49.css"];
export const fonts = [];
