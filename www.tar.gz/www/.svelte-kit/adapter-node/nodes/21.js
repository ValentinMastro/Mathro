

export const index = 21;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/cours/6eme/chapitre00/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/21.70c9ba0e.js","_app/immutable/chunks/scheduler.2cdf953d.js","_app/immutable/chunks/index.cba2a906.js","_app/immutable/chunks/each.e59479a4.js","_app/immutable/chunks/Propriete.17c97378.js"];
export const stylesheets = ["_app/immutable/assets/21.ede682c1.css","_app/immutable/assets/Propriete.9d2d561c.css"];
export const fonts = [];
