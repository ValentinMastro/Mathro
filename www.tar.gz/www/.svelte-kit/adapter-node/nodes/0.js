

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.9073c3f2.js","_app/immutable/chunks/scheduler.2cdf953d.js","_app/immutable/chunks/index.cba2a906.js","_app/immutable/chunks/singletons.d4c29b80.js","_app/immutable/chunks/stores.14d52ce1.js"];
export const stylesheets = ["_app/immutable/assets/0.ea7efa0c.css"];
export const fonts = [];
