

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/cours/4eme/chapitre01/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/6.25387715.js","_app/immutable/chunks/scheduler.2cdf953d.js","_app/immutable/chunks/index.cba2a906.js","_app/immutable/chunks/Propriete.17c97378.js","_app/immutable/chunks/each.e59479a4.js","_app/immutable/chunks/types.02c09cd6.js"];
export const stylesheets = ["_app/immutable/assets/6.613fb929.css","_app/immutable/assets/Propriete.9d2d561c.css"];
export const fonts = [];
