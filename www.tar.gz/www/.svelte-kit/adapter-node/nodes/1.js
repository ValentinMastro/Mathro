

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.ea5873dd.js","_app/immutable/chunks/scheduler.2cdf953d.js","_app/immutable/chunks/index.cba2a906.js","_app/immutable/chunks/stores.14d52ce1.js","_app/immutable/chunks/singletons.d4c29b80.js"];
export const stylesheets = [];
export const fonts = [];
