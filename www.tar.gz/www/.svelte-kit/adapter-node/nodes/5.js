

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/cours/4eme/chapitre00/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.a7f6c1e1.js","_app/immutable/chunks/scheduler.2cdf953d.js","_app/immutable/chunks/index.cba2a906.js","_app/immutable/chunks/Propriete.17c97378.js","_app/immutable/chunks/each.e59479a4.js","_app/immutable/chunks/ch00.8f3986eb.js","_app/immutable/chunks/types.02c09cd6.js"];
export const stylesheets = ["_app/immutable/assets/Propriete.9d2d561c.css"];
export const fonts = [];
