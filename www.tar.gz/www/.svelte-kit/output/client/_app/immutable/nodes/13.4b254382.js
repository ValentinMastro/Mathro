import{s}from"../chunks/scheduler.2cdf953d.js";import{S as t,i as e}from"../chunks/index.cba2a906.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
