export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png","fonts/Marianne-Bold.otf","fonts/Marianne-BoldItalic.otf","fonts/Marianne-ExtraBold.otf","fonts/Marianne-ExtraBoldItalic.otf","fonts/Marianne-Light.otf","fonts/Marianne-LightItalic.otf","fonts/Marianne-Medium.otf","fonts/Marianne-MediumItalic.otf","fonts/Marianne-Regular.otf","fonts/Marianne-RegularItalic.otf","fonts/Marianne-Thin.otf","fonts/Marianne-ThinItalic.otf","images/Euclide.jpg","images/Pythagoras.jpg","images/gateau.png","robots.txt"]),
	mimeTypes: {".png":"image/png",".otf":"font/otf",".jpg":"image/jpeg",".txt":"text/plain"},
	_: {
		client: {"start":"_app/immutable/entry/start.649a7ef0.js","app":"_app/immutable/entry/app.60ab635f.js","imports":["_app/immutable/entry/start.649a7ef0.js","_app/immutable/chunks/scheduler.2cdf953d.js","_app/immutable/chunks/singletons.d4c29b80.js","_app/immutable/entry/app.60ab635f.js","_app/immutable/chunks/scheduler.2cdf953d.js","_app/immutable/chunks/index.cba2a906.js"],"stylesheets":[],"fonts":[]},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js')),
			__memo(() => import('./nodes/6.js')),
			__memo(() => import('./nodes/7.js')),
			__memo(() => import('./nodes/8.js')),
			__memo(() => import('./nodes/9.js')),
			__memo(() => import('./nodes/10.js')),
			__memo(() => import('./nodes/11.js')),
			__memo(() => import('./nodes/12.js')),
			__memo(() => import('./nodes/13.js')),
			__memo(() => import('./nodes/14.js')),
			__memo(() => import('./nodes/15.js')),
			__memo(() => import('./nodes/16.js')),
			__memo(() => import('./nodes/17.js')),
			__memo(() => import('./nodes/18.js')),
			__memo(() => import('./nodes/19.js')),
			__memo(() => import('./nodes/20.js')),
			__memo(() => import('./nodes/21.js')),
			__memo(() => import('./nodes/22.js')),
			__memo(() => import('./nodes/23.js')),
			__memo(() => import('./nodes/24.js')),
			__memo(() => import('./nodes/25.js')),
			__memo(() => import('./nodes/26.js')),
			__memo(() => import('./nodes/27.js')),
			__memo(() => import('./nodes/28.js')),
			__memo(() => import('./nodes/29.js')),
			__memo(() => import('./nodes/30.js')),
			__memo(() => import('./nodes/31.js')),
			__memo(() => import('./nodes/32.js')),
			__memo(() => import('./nodes/33.js')),
			__memo(() => import('./nodes/34.js')),
			__memo(() => import('./nodes/35.js')),
			__memo(() => import('./nodes/36.js')),
			__memo(() => import('./nodes/37.js')),
			__memo(() => import('./nodes/38.js')),
			__memo(() => import('./nodes/39.js')),
			__memo(() => import('./nodes/40.js')),
			__memo(() => import('./nodes/41.js')),
			__memo(() => import('./nodes/42.js'))
		],
		routes: [
			{
				id: "/api",
				pattern: /^\/api\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/_server.ts.js'))
			},
			{
				id: "/cours/4eme",
				pattern: /^\/cours\/4eme\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre00",
				pattern: /^\/cours\/4eme\/chapitre00\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre01",
				pattern: /^\/cours\/4eme\/chapitre01\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre02",
				pattern: /^\/cours\/4eme\/chapitre02\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre03",
				pattern: /^\/cours\/4eme\/chapitre03\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre04",
				pattern: /^\/cours\/4eme\/chapitre04\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre05",
				pattern: /^\/cours\/4eme\/chapitre05\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre06",
				pattern: /^\/cours\/4eme\/chapitre06\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 10 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre07",
				pattern: /^\/cours\/4eme\/chapitre07\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 11 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre08",
				pattern: /^\/cours\/4eme\/chapitre08\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre09",
				pattern: /^\/cours\/4eme\/chapitre09\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 13 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre10",
				pattern: /^\/cours\/4eme\/chapitre10\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre11",
				pattern: /^\/cours\/4eme\/chapitre11\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 15 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre12",
				pattern: /^\/cours\/4eme\/chapitre12\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 16 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre13",
				pattern: /^\/cours\/4eme\/chapitre13\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 17 },
				endpoint: null
			},
			{
				id: "/cours/4eme/chapitre14",
				pattern: /^\/cours\/4eme\/chapitre14\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 18 },
				endpoint: null
			},
			{
				id: "/cours/6eme",
				pattern: /^\/cours\/6eme\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 19 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre00",
				pattern: /^\/cours\/6eme\/chapitre00\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 20 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre01",
				pattern: /^\/cours\/6eme\/chapitre01\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 21 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre02",
				pattern: /^\/cours\/6eme\/chapitre02\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 22 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre03",
				pattern: /^\/cours\/6eme\/chapitre03\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 23 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre04",
				pattern: /^\/cours\/6eme\/chapitre04\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 24 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre05",
				pattern: /^\/cours\/6eme\/chapitre05\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 25 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre06",
				pattern: /^\/cours\/6eme\/chapitre06\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 26 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre07",
				pattern: /^\/cours\/6eme\/chapitre07\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 27 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre08",
				pattern: /^\/cours\/6eme\/chapitre08\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 28 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre09",
				pattern: /^\/cours\/6eme\/chapitre09\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 29 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre10",
				pattern: /^\/cours\/6eme\/chapitre10\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 30 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre11",
				pattern: /^\/cours\/6eme\/chapitre11\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 31 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre12",
				pattern: /^\/cours\/6eme\/chapitre12\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 32 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre13",
				pattern: /^\/cours\/6eme\/chapitre13\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 33 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre14",
				pattern: /^\/cours\/6eme\/chapitre14\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 34 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre15",
				pattern: /^\/cours\/6eme\/chapitre15\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 35 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre16",
				pattern: /^\/cours\/6eme\/chapitre16\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 36 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre17",
				pattern: /^\/cours\/6eme\/chapitre17\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 37 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre18",
				pattern: /^\/cours\/6eme\/chapitre18\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 38 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre19",
				pattern: /^\/cours\/6eme\/chapitre19\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 39 },
				endpoint: null
			},
			{
				id: "/cours/6eme/chapitre20",
				pattern: /^\/cours\/6eme\/chapitre20\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 40 },
				endpoint: null
			},
			{
				id: "/exercices",
				pattern: /^\/exercices\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 41 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		}
	}
}
})();
