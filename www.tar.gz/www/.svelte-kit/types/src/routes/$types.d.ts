import type * as Kit from '@sveltejs/kit';

type Expand<T> = T extends infer O ? { [K in keyof O]: O[K] } : never;
type RouteParams = {  }
type RouteId = '/';
type MaybeWithVoid<T> = {} extends T ? T | void : T;
export type RequiredKeys<T> = { [K in keyof T]-?: {} extends { [P in K]: T[K] } ? never : K; }[keyof T];
type OutputDataShape<T> = MaybeWithVoid<Omit<App.PageData, RequiredKeys<T>> & Partial<Pick<App.PageData, keyof T & keyof App.PageData>> & Record<string, any>>
type EnsureDefined<T> = T extends null | undefined ? {} : T;
type OptionalUnion<U extends Record<string, any>, A extends keyof U = U extends U ? keyof U : never> = U extends unknown ? { [P in Exclude<A, keyof U>]?: never } & U : never;
export type Snapshot<T = any> = Kit.Snapshot<T>;
type PageParentData = EnsureDefined<LayoutData>;
type LayoutRouteId = RouteId | "/" | "/cours/4eme" | "/cours/4eme/chapitre00" | "/cours/4eme/chapitre01" | "/cours/4eme/chapitre02" | "/cours/4eme/chapitre03" | "/cours/4eme/chapitre04" | "/cours/4eme/chapitre05" | "/cours/4eme/chapitre06" | "/cours/4eme/chapitre07" | "/cours/4eme/chapitre08" | "/cours/4eme/chapitre09" | "/cours/4eme/chapitre10" | "/cours/4eme/chapitre11" | "/cours/4eme/chapitre12" | "/cours/4eme/chapitre13" | "/cours/4eme/chapitre14" | "/cours/6eme" | "/cours/6eme/chapitre00" | "/cours/6eme/chapitre01" | "/cours/6eme/chapitre02" | "/cours/6eme/chapitre03" | "/cours/6eme/chapitre04" | "/cours/6eme/chapitre05" | "/cours/6eme/chapitre06" | "/cours/6eme/chapitre07" | "/cours/6eme/chapitre08" | "/cours/6eme/chapitre09" | "/cours/6eme/chapitre10" | "/cours/6eme/chapitre11" | "/cours/6eme/chapitre12" | "/cours/6eme/chapitre13" | "/cours/6eme/chapitre14" | "/cours/6eme/chapitre15" | "/cours/6eme/chapitre16" | "/cours/6eme/chapitre17" | "/cours/6eme/chapitre18" | "/cours/6eme/chapitre19" | "/cours/6eme/chapitre20" | "/exercices" | null
type LayoutParams = RouteParams & {  }
type LayoutParentData = EnsureDefined<{}>;

export type PageServerData = null;
export type PageLoad<OutputData extends OutputDataShape<PageParentData> = OutputDataShape<PageParentData>> = Kit.Load<RouteParams, PageServerData, PageParentData, OutputData, RouteId>;
export type PageLoadEvent = Parameters<PageLoad>[0];
export type PageData = Expand<Omit<PageParentData, keyof PageParentData & EnsureDefined<PageServerData>> & OptionalUnion<EnsureDefined<PageParentData & EnsureDefined<PageServerData>>>>;
export type LayoutServerData = null;
export type LayoutData = Expand<LayoutParentData>;