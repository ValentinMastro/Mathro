<script>
    import './styles.css'
</script>

<slot />