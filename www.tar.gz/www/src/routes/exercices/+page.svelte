<script lang="ts">
	import Exercice from "./Exercice.svelte";
</script>

<svelte:window  />

<svelte:head>
	<title>Sverdle</title>
	<meta name="description" content="A Wordle clone written in SvelteKit" />
</svelte:head>

<Exercice />

<style>

</style>
