<script lang="ts">

</script>

<div>
    <u>Remarque :</u><br />
    <slot />
</div>

<style>
    div {
        color: black;
    }
</style>