<script lang="ts">

</script>

<div>
    <u>Propriété :</u><br />
    <slot />
</div>

<style>
    div {
        color: red;
    }
</style>