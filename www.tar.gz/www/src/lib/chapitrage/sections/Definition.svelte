<script lang="ts">

</script>

<div>
    <u>Définition :</u><br />
    <slot />
</div>

<style>
    div {
        color: green;
    }
</style>